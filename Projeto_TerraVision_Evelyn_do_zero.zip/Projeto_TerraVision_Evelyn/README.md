# Análise Forense TerraVision — Zonas Desérticas e Camadas de Areia

**Estudante:** Evelyn Kauany Lemes da Silva  
**Turma:** 3ºD — Desenvolvimento de Sistemas  
**Professora:** Angélica Neckel  
**Tema designado:** Zonas Desérticas e Camadas de Areia (Uniformes e Dunas)  
**Disciplinas integradas:** Ciência de Dados, Computação Gráfica, Front-End, Banco de Dados, Lógica de Programação, UX/UI e Análise Forense Computacional.

---

## 1. Apresentação do projeto

Este projeto relaciona conceitos de Ciência de Dados e Computação Gráfica ao caso TerraVision, abordado na minissérie *A Batalha Bilionária: O Caso Google Earth*. O foco desta análise é a visualização de regiões desérticas, considerando a seleção de níveis de detalhe de acordo com a altitude da câmera virtual.

Em sistemas de visualização geográfica, não é eficiente carregar todos os detalhes de uma região quando o usuário observa o planeta em grande altitude. Por isso, a técnica de **Level of Detail (LoD)** seleciona diferentes níveis de resolução conforme a distância ou altitude da câmera.

Neste trabalho, essa lógica é aplicada a um cenário desértico, no qual a visualização pode variar desde um mosaico geral da Terra até detalhes de cristas, faces e ondulações de dunas.

## 2. Objetivo

Desenvolver uma simulação em Python que selecione a camada de visualização adequada para diferentes altitudes e documentar desafios de processamento de imagens, princípios de Gestalt e aspectos de UX/UI relacionados à exploração de terrenos desérticos.

## 3. Etapa 1 — Ciência de Dados e Lógica

O arquivo [`script.py`](./script.py) contém a função `carregar_camada_satelite(lista_altitudes)`. Ela recebe uma lista com pelo menos cinco altitudes, percorre os valores com uma estrutura de repetição e utiliza estruturas condicionais (`if`, `elif` e `else`) para indicar o nível de renderização.

### 3.1 Regras de seleção do nível de detalhe

| Altitude da câmera | Nível | Elementos previstos para renderização |
|---|---|---|
| Acima de 10.000 m | Baixa resolução | Mosaico geral da Terra e identificação ampla das regiões áridas |
| De 1.000 m até 10.000 m | Média resolução | Distribuição regional de áreas arenosas, campos de dunas e transições entre areia e rocha |
| Abaixo de 1.000 m | Alta resolução | Cristas, faces, ondulações, pequenas depressões e limites entre sedimentos |

**Observação:** os limites seguem as faixas definidas no enunciado. O programa é uma simulação lógica: ele informa qual camada deveria ser selecionada, mas não realiza o carregamento de imagens de satélite.

### 3.2 Como executar

É necessário ter Python 3 instalado. No terminal, dentro da pasta do projeto, execute:

```bash
python script.py
```

O programa utiliza seis valores de teste: `25000`, `12000`, `5000`, `1500`, `800` e `250` metros. Assim, demonstra as três faixas de resolução solicitadas.

## 4. Etapa 2 — Computação Gráfica e UX/UI

### 4.1 Processamento e tratamento de imagens

A renderização de regiões desérticas apresenta desafios específicos:

- **Costura de imagens (stitching):** imagens capturadas em momentos, ângulos ou condições atmosféricas diferentes podem apresentar emendas visíveis. O sistema precisa alinhar as cenas e reduzir diferenças nas bordas para formar um mosaico contínuo.
- **Uniformização de cor e luminosidade:** a areia pode variar entre tons claros, amarelos, alaranjados e avermelhados. A incidência solar, as sombras e as condições de captura podem criar diferenças de tonalidade entre imagens vizinhas.
- **Textura e contraste:** dunas próximas podem apresentar padrões semelhantes. O processamento precisa preservar cristas, depressões e ondulações sem apagar detalhes nem criar contrastes artificiais.
- **Mudança de resolução com o zoom:** ao afastar a câmera, detalhes muito pequenos deixam de ser necessários; ao aproximar, o sistema deve apresentar imagens mais detalhadas. A transição entre níveis precisa evitar mudanças bruscas, borrões e efeitos de cintilação.

Esses cuidados contribuem para uma visualização contínua e compreensível do relevo desértico.

### 4.2 Leis da Gestalt na interface

**Lei da Figura-Fundo:** a interface precisa diferenciar os elementos principais do mapa do fundo visual. Em uma região desértica, uma legenda, um marcador ou uma área selecionada deve se destacar da textura da areia, permitindo que o usuário identifique rapidamente o elemento analisado.

**Lei da Continuidade:** linhas e formas que seguem uma direção tendem a ser percebidas como contínuas. Na exploração de dunas, a continuidade visual ajuda o usuário a acompanhar cristas, limites de campos de areia e transições do relevo durante a navegação e o zoom.

**Lei da Proximidade:** elementos próximos tendem a ser percebidos como pertencentes a um mesmo grupo. Na interface, marcadores, legendas e controles relacionados podem ficar agrupados para facilitar a leitura e reduzir a confusão durante a exploração.

### 4.3 Como o design facilita a navegação

Uma interface geográfica eficiente deve manter os controles de zoom e orientação em posições previsíveis, apresentar legenda legível e utilizar marcadores com contraste suficiente em relação ao terreno. A hierarquia visual deve orientar a atenção sem encobrir as informações do mapa. A mudança de escala deve preservar a referência espacial do usuário.

## 5. Imagens e evidências

### 5.1 Imagem ilustrativa do ambiente desértico

A imagem abaixo foi incluída como referência visual complementar para a discussão de paisagens áridas e formações rochosas. Ela não substitui a captura de tela exigida do Google Earth.

![Paisagem desértica de referência](./deserto-saara.png)

### 5.2 Evidência obrigatória do Google Earth

**Inserir aqui uma captura de tela real do Google Earth mostrando uma área desértica do tema designado, preferencialmente um campo de dunas do Saara.**

Para completar esta seção:

1. Abra o Google Earth.
2. Pesquise por **Grande Mar de Areia, Saara** ou outra área de dunas do Saara.
3. Ajuste o zoom para que as dunas e suas formas sejam identificáveis.
4. Faça uma captura de tela em que apareçam o terreno e a localização pesquisada.
5. Salve a captura na pasta do repositório com o nome `google-earth-saara.png`.
6. Depois, substitua esta orientação pela linha abaixo:

```markdown
![Captura do Google Earth mostrando dunas do Saara](./google-earth-saara.png)
```

**Atenção:** não apresente a imagem ilustrativa como se fosse uma captura do Google Earth. A evidência precisa ser obtida diretamente da ferramenta solicitada.

## 6. Relação com a minissérie

O caso TerraVision permite discutir como dados geográficos, processamento de imagens, visualização tridimensional e desempenho computacional se relacionam em sistemas de exploração do planeta.

- **Ideia e protótipo:** a organização de dados geográficos e a criação de uma interface visual tornam possível transformar informações espaciais em uma experiência navegável.
- **Apresentação e algoritmo:** estruturas de dados, operações com matrizes e otimização ajudam a processar imagens e selecionar níveis de detalhe.
- **Lançamento e disputa:** a comparação entre sistemas de visualização também envolve arquitetura de software, experiência do usuário e questões de propriedade intelectual.
- **Análise forense e julgamento:** a perícia computacional exige examinar evidências técnicas com método, documentar procedimentos e comunicar conclusões de forma compreensível.

## 7. Conclusão

A atividade demonstra como a seleção de nível de detalhe pode tornar a visualização geográfica mais eficiente. No cenário desértico, a escolha adequada da resolução permite apresentar primeiro a distribuição geral das regiões áridas e, conforme a aproximação da câmera, revelar características como campos de dunas, cristas e ondulações da areia.

A análise também mostra que a qualidade de um sistema de mapas não depende apenas do algoritmo: o tratamento das imagens e a organização da interface são fundamentais para que o usuário interprete o terreno corretamente.

## 8. Estrutura do repositório

```text
Analise-forense-terravision-evelyn-lemes/
├── README.md
├── script.py
├── deserto-saara.png
└── google-earth-saara.png   (adicionar a captura real)
```

## 9. Histórico de versionamento

Registre as alterações realizadas no GitHub com mensagens claras, por exemplo:

- `docs: cria relatório de análise forense TerraVision`
- `feat: implementa seleção de camadas por altitude`
- `docs: adiciona imagem ilustrativa do cenário desértico`
- `docs: adiciona evidência do Google Earth`

---

**Projeto acadêmico individual — Desenvolvimento de Sistemas.**
