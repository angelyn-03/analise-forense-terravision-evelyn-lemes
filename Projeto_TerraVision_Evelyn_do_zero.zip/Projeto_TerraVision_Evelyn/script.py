"""
Projeto: Análise Forense TerraVision
Tema individual: Zonas Desérticas e Camadas de Areia (Uniformes e Dunas)
Autora: Evelyn Kauany Lemes da Silva

Simulação didática de seleção de nível de detalhe (LoD) conforme a altitude
da câmera virtual. O programa não carrega imagens reais: ele informa qual
camada temática deveria ser renderizada em cada faixa de altitude.
"""

def carregar_camada_satelite(lista_altitudes):
    """
    Recebe uma lista com pelo menos cinco altitudes, em metros, e informa
    a camada de visualização adequada para o cenário desértico.

    Regras da atividade:
    - altitude > 10.000 m: baixa resolução (mosaico geral);
    - 1.000 m <= altitude <= 10.000 m: média resolução (mosaico regional);
    - altitude < 1.000 m: alta resolução (detalhes finos).
    """
    if not isinstance(lista_altitudes, (list, tuple)):
        raise TypeError("A entrada deve ser uma lista ou tupla de altitudes.")

    if len(lista_altitudes) < 5:
        raise ValueError("Informe pelo menos cinco valores de altitude.")

    print("ANÁLISE DE CAMADAS DE SENSORIAMENTO REMOTO — CENÁRIO DESÉRTICO")
    print("-" * 68)

    for indice, altitude in enumerate(lista_altitudes, start=1):
        if not isinstance(altitude, (int, float)) or isinstance(altitude, bool):
            print(f"Teste {indice}: valor inválido ({altitude!r}). Informe altitude numérica.")
            continue

        if altitude < 0:
            print(f"Teste {indice}: altitude inválida ({altitude} m). A altitude não pode ser negativa.")
        elif altitude > 10000:
            print(
                f"Teste {indice} | {altitude:,.0f} m: BAIXA RESOLUÇÃO — "
                "mosaico geral da Terra, com identificação ampla das grandes "
                "regiões áridas e da distribuição dos desertos."
            )
        elif altitude >= 1000:
            print(
                f"Teste {indice} | {altitude:,.0f} m: MÉDIA RESOLUÇÃO — "
                "mosaico regional do deserto, destacando a distribuição das "
                "áreas arenosas, campos de dunas e transições entre areia e rocha."
            )
        else:
            print(
                f"Teste {indice} | {altitude:,.0f} m: ALTA RESOLUÇÃO — "
                "detalhes finos das cristas e faces das dunas, padrões de ondulação "
                "da areia, pequenas depressões e limites entre sedimentos."
            )

    print("-" * 68)


if __name__ == "__main__":
    # Cinco ou mais altitudes para demonstrar a mudança de nível de detalhe.
    altitudes_teste = [25000, 12000, 5000, 1500, 800, 250]
    carregar_camada_satelite(altitudes_teste)
